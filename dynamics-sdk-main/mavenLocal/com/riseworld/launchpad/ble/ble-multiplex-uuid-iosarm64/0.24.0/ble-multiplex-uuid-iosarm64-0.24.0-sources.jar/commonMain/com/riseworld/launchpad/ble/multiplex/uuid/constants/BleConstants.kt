package com.riseworld.launchpad.ble.multiplex.uuid.constants

import com.riseworld.launchpad.ble.multiplex.uuid.BleUuid
import kotlin.uuid.Uuid

/**
 * @author Research Industrial Systems Engineering (RISE) Forschungs-, Entwicklungs- und Großprojektberatung GmbH
 */

/**
 * The bluetooth UUID defined by SIG.
 */
private fun String.asBluetoothBaseUuid(): Uuid {
    require(this.length == 4)
    return Uuid.parse("0000$this-0000-1000-8000-00805f9b34fb")
}

val GENERIC_ACCESS_SERVICE = "1800".asBluetoothBaseUuid()
val DEVICE_NAME_CHARACTERISTIC = "2A00".asBluetoothBaseUuid()

val DEVICE_INFORMATION_SERVICE = "180A".asBluetoothBaseUuid()
val MODEL_NUMBER_CHARACTERISTIC = "2A24".asBluetoothBaseUuid()
val SERIAL_NUMBER_CHARACTERISTIC = "2A25".asBluetoothBaseUuid()
val FIRMWARE_REVISION_CHARACTERISTIC = "2A26".asBluetoothBaseUuid()
val HARDWARE_REVISION_CHARACTERISTIC = "2A27".asBluetoothBaseUuid()
val MANUFACTURER_NAME_CHARACTERISTIC = "2A29".asBluetoothBaseUuid()

val BATTERY_SERVICE = "180F".asBluetoothBaseUuid()
val BATTERY_LEVEL_CHARACTERISTIC = "2A19".asBluetoothBaseUuid()
val BATTERY_LEVEL_STATUS_CHARACTERISTIC = "2BED".asBluetoothBaseUuid()

val BATTERY_LEVEL_UUID by lazy {
    BleUuid(
        service = BATTERY_SERVICE,
        characteristic = BATTERY_LEVEL_CHARACTERISTIC,
        alias = "Battery Level",
    )
}

val BATTERY_LEVEL_STATUS_UUID by lazy {
    BleUuid(
        service = BATTERY_SERVICE,
        characteristic = BATTERY_LEVEL_STATUS_CHARACTERISTIC,
        alias = "Battery Level Status",
    )
}
