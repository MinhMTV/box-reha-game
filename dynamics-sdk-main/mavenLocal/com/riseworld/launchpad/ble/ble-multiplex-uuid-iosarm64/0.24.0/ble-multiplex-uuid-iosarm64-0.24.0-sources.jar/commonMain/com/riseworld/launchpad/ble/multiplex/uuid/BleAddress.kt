package com.riseworld.launchpad.ble.multiplex.uuid

import kotlin.jvm.JvmInline

/**
 * @author Research Industrial Systems Engineering (RISE) Forschungs-, Entwicklungs- und Großprojektberatung GmbH
 */
@JvmInline
value class BleAddress(
    val value: String,
)
