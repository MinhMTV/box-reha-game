package com.riseworld.launchpad.ble.multiplex.uuid.exception

/**
 * @author Research Industrial Systems Engineering (RISE) Forschungs-, Entwicklungs- und Großprojektberatung GmbH
 */
class InvalidVersionFormatException(
    message: String,
) : Exception(message)
