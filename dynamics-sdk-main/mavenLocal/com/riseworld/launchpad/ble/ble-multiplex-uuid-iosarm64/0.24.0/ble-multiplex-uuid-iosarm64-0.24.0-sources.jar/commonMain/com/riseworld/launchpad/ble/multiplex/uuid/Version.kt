package com.riseworld.launchpad.ble.multiplex.uuid

import com.riseworld.launchpad.ble.multiplex.uuid.exception.InvalidVersionFormatException

/**
 * @author Research Industrial Systems Engineering (RISE) Forschungs-, Entwicklungs- und Großprojektberatung GmbH
 */
data class Version(
    val major: Int,
    val minor: Int,
    val patch: Int,
    val suffix: String? = null,
) : Comparable<Version> {
    override fun compareTo(other: Version): Int {
        if (major != other.major) {
            return major.compareTo(other.major)
        }
        if (minor != other.minor) {
            return minor.compareTo(other.minor)
        }
        return patch.compareTo(other.patch)
    }

    override fun toString() = "$major.$minor.$patch${if (suffix.isNullOrEmpty()) "" else suffix}"
}

// Regex for parsing version strings.
// Inspired by https://semver.org/#is-there-a-suggested-regular-expression-regex-to-check-a-semver-string
private val versionRegex by lazy {
    Regex("""v?(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))?""")
}

// Same as versionRegex, but allows suffixes
private val lenientVersionRegex by lazy {
    Regex("""v?(0|[1-9]\d*)\.(0|[1-9]\d*)(?:\.(0|[1-9]\d*))(.*)""")
}

/**
 * @param rawVersion the raw version string
 * @param isLenient if true, then suffixes to a valid version string are allowed.
 */
@Throws(InvalidVersionFormatException::class)
fun parseVersion(
    rawVersion: String,
    isLenient: Boolean = false,
): Version {
    val matchResult = (if (isLenient) lenientVersionRegex else versionRegex).matchEntire(rawVersion)
    if (matchResult != null) {
        try {
            val components = matchResult.destructured.toList()
            val majorInt = components[0].toInt()
            val minorInt = components[1].toInt()
            val patchInt = components[2].toIntOrNull() ?: 0
            return Version(
                majorInt,
                minorInt,
                patchInt,
                components.getOrNull(3),
            )
        } catch (e: NumberFormatException) {
            throw InvalidVersionFormatException("Invalid numeric format in version string: $rawVersion")
        }
    } else {
        throw InvalidVersionFormatException("Invalid version format: $rawVersion, isLenient is $isLenient")
    }
}
