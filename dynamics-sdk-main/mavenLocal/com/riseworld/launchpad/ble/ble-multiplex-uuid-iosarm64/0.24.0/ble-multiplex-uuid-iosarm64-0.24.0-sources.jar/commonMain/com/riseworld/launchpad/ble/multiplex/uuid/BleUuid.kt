package com.riseworld.launchpad.ble.multiplex.uuid

import kotlin.uuid.Uuid

/**
 * A wrapper class for holding a [service] UUID and a [characteristic] UUID which can be used to address a specific
 * bluetooth LE Api.
 * - [alias] is an optional string property for which a human-readable name can be set to reduce verbosity in the logs.
 *
 * @author Research Industrial Systems Engineering (RISE) Forschungs-, Entwicklungs- und Großprojektberatung GmbH
 */
data class BleUuid(
    val service: Uuid,
    val characteristic: Uuid,
    val alias: String? = null,
) {
    override fun toString(): String = "BleUuid(service=$service, characteristic=$characteristic, alias=$alias)"

    val shortString: String
        get() {
            return "BleUuid(${if (!alias.isNullOrEmpty()) "alias=$alias, " else ""}" +
                "service=${service.bleHandle()}, characteristic=${characteristic.bleHandle()})"
        }
}

/**
 * @return the BLE "handle" part of a BLE service or characteristic Uuid, this is usually the part
 * in the [Uuid] which is mostly unique across all defined BLE Uuids.
 */
fun Uuid.bleHandle() = "0x${this.toString().substring(4).substringBefore("-")}"
